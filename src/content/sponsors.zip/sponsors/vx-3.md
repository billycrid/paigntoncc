---
title: VX-3
description: VX-3
logo: https://img-res.pitchero.com/?url=images.pitchero.com%2Fclub_sponsors%2F76076%2F1665770875_large.jpg&bg=ffffff&h=68&w=160&t=frame&q=null
address: Kemmings Close, Paignton, TQ4 7TW
website: https://vx-3.com/
sponsoring: club
---
