---
title: Paignton Rugby Club
description: Paignton Rugby Club
logo: https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8eeAQXDO62XaNdowOBclHFLB4dRcuVFCi7A&s
address: 
website: https://www.facebook.com/paigntonrugby/?locale=en_GB
sponsoring: player
---
