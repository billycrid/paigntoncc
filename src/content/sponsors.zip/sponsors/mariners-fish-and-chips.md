---
title: Mariners Fish & Chips
description: Mariners Fish & Chips
logo: https://www.glutenfreedining.co.uk/wp-content/uploads/2018/08/Mariners-Paignton-Logo.jpg
address: 8 Parkside Road, Paignton, TQ4 6AE
website: https://www.marinersfishandchips.co.uk/
sponsoring: player
---
