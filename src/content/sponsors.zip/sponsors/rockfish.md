---
title: Rockfish
description: Rockfish
logo: https://therockfish.co.uk/cdn/shop/t/113/assets/logo.svg?v=131516703183070619801740577227#blue
address: 5 South Embankment, Dartmouth, TQ6 9BH
website: https://therockfish.co.uk/
sponsoring: player
---
