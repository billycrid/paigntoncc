---
title: Gurkhas Diner - Paignton
description: Gurkhas Diner - Paignton
logo: 
address: 52 Victoria Street, Paignton, TQ4 5DS
website: 
sponsoring: player
---
