---
title: Harbour Light - St Austell Brewery
description: Harbour Light - St Austell Brewery
logo: 
address: North Quay, Paignton, TQ4 6du
website: 
sponsoring: club
---
