---
title: Gibbs & Lugg
description: Gibbs & Lugg
logo: 
address: The Workshop, Victora Park Road, Torquay, TQ1 3QH
website: 
sponsoring: club
---
